<?php
    include_once 'sp_mz.php';
?>
   <div id="okno">
  
  </div> 
  
<?php
    include_once 'footer.php';
?>
    </body>
</html>
