<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
		<link rel="stylesheet" type="text/css" href="sporocila_meni.css" />
    </head>
    <body>
 <?php
    include_once 'header.php';
    include_once 'database.php';
?>
<form>
  
  <div id="glavnimeni">
  
  <div id="sporočila">
  <h1>PONUDBE</h1>
  </div>
  
  
  
  </div>
  
  <div id="spodnjimeni">
  
  <div id="izbira">
  
  
  
  <div id="prejeta">
  <a href="prejeta_sporocila.php">Pregled ponudb</a>
  </div>

  
  </div>
  </form>