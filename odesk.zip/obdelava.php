<?php 
include_once 'database.php';

$naslov=$_POST["zadeva"];
$ocena=$_POST["ocena"];
$feed=$_POST["id"];
$query =   "INSERT INTO skills (title,description,feedback)
						VALUES ('$naslov','$ocena','$feed');";
mysqli_query($link, $query);
    
Header("Location:users.php");

?>

