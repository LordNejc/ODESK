<form>

<div id="opcije">
  
  <div id="izbriši">
  Izbriši 
  </div>
  
  <div id="uredi">
  Uredi
  </div>
  </div>
  
  </div>
  
 
  
  </form>
  
  
  
 

<?php
    include_once 'footer.php';
?>
    </body>
</html>
